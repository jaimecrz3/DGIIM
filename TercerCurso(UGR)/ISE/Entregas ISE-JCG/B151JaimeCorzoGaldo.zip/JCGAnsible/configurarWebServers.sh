#!/bin/bash

INVENTARIO="inventario_web.ini"
PLAYBOOK="playbook2.yml"
CLAVE="/home/usuario/Documentos/Universidad/CuartoCurso/ISE/JCGAnsible/keys/admin_id_rsa"

ansible-playbook -i "$INVENTARIO" "$PLAYBOOK" --private-key "$CLAVE" -u admin

echo "Servidores web configurados correctamente"
echo "En un navegador escribir 192.168.56.102:80 para Apache o 192.168.56.103:80 para Nginx"



#!/bin/bash

echo "Apagando máquinas virtuales:"
VBoxManage controlvm Ser1-Ansible acpipowerbutton
VBoxManage controlvm Ser2-Ansible acpipowerbutton



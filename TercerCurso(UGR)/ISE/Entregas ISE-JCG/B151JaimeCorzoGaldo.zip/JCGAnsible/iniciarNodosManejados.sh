#!/bin/bash

echo "1. Iniciandolas Máquinas virtuales:"

VBoxManage startvm Ser1-Ansible --type headless
VBoxManage startvm Ser2-Ansible --type headless

echo "2.Esperando a que los nodos estén disponibles por SSH como root:"

ips=("192.168.56.102" "192.168.56.103")

for ip in "${ips[@]}"; do
  echo -n "Esperando $ip... "
  until ssh -o StrictHostKeyChecking=no jaime@$ip "echo OK" &>/dev/null; do
    sleep 2
  done
  echo "Disponible"
done

ansible-playbook -i inventario.ini playbook1.yml

echo "Nodos configurados con acceso admin"

